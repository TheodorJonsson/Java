package se.umu.cs.apjava.bakery;

public class ChocolateCake extends Cake {
    public ChocolateCake(){
        addCost(10);
        super.setDescription("Chocolate Cake");
    }
}
