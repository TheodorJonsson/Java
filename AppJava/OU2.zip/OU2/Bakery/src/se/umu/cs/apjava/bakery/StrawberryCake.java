package se.umu.cs.apjava.bakery;

public class StrawberryCake extends Cake {
    public StrawberryCake(){
        addCost(20);
        super.setDescription("Strawberry Cake");
    }

}

