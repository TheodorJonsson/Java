package se.umu.cs.apjava.bakery;

public class VanillaCake extends Cake {
    public VanillaCake(){
        addCost(10);
        super.setDescription("Vanilla Cake");
    }

}
