package se.umu.cs.apjava.maxdonalds.burger;

public interface BurgerFactory {
    Burger createBurger();
}
