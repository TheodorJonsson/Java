import javax.swing.*;

public class main extends EditorTextView {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(EditorTextView::new);
    }
}
