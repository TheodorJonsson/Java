import javax.swing.*;
import radioGUI.*;

public class RadioInfo {
    public static void main(String[] args) {
            SwingUtilities.invokeLater(()->new MainMenu());
    }
}
