/**
 * Handles what happens when you click on the list and is responsible for
 * creating the new initializing the frames and adding them to the main frames menubar.
 * Written and compiled in Java 17
 *
 * @Author Theodor Jonsson (ens18trn)
 * @date 2023-01-09
 */
package radioController;

import radioGUI.*;
import radioXML.ChannelList;
import radioXML.ParseChannel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;



public class ListSelectionHandler {
    private MainMenu menu;
    private ChannelList channelList;


    public ListSelectionHandler(MainMenu menu, ChannelList channelList){
        this.menu = menu;
        this.channelList = channelList;
        init_ListListener();

    }

    /**
     * Creates a mouselistener for the JList that has the all the channels
     * Which will start the SwingWorker that parses the individual channels.
     */
    private void init_ListListener(){
        menu.getListOfChannels().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // If the user double clicks with mouse 1
                if(e.getClickCount() == 2 && e.getButton() == MouseEvent.BUTTON1){
                    int index = menu.getListOfChannels().getSelectedIndex();
                    //Creates a new JFrame for the channel
                    channelList.getListOfChannels().get(index).createTable();
                    ScheduleMenu sMenu = new ScheduleMenu(channelList.getListOfChannels().get(index));
                    menu.addMenuItem(channelList.getListOfChannels().get(index).getName(), sMenu);
                    //Parses the individual channel and sends the data to newly created JFrame
                    ParseChannel parseChannel = new ParseChannel(channelList.getListOfChannels().get(index));
                    parseChannel.execute();
            }
        }
    });
    }
}
