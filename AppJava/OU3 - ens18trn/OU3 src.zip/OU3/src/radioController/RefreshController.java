/**
 * Handles the refresh button and the timer to automatically refresh the table
 * Written and compiled in Java 17
 *
 * @Author Theodor Jonsson (ens18trn)
 * @date 2023-01-09
 */
package radioController;

import radioGUI.ScheduleMenu;
import radioXML.Channel;
import radioXML.ParseChannel;

import java.util.Timer;
import java.util.TimerTask;


public class RefreshController {
    private ScheduleMenu sMenu;
    private Channel channel;
    private Timer refreshTimer;


    public RefreshController(ScheduleMenu sMenu, Channel channel){
        this.sMenu = sMenu;
        this.channel = channel;
        int timeToRefresh = 3600000; //It's counted in ms so 3.6m ms is one hour
        init_Listener();
        refreshTimer = new Timer();
        refreshTimer.schedule(new TimerTask(){
            @Override
            public void run(){
                refreshTable();
            } 
        },timeToRefresh, timeToRefresh);
    }

    /**
     * Adds a action listener to the refresh button so that it calls the refreshTable function
     */
    private void init_Listener(){
        sMenu.getRefreshButton().addActionListener(e->refreshTable());
    }

    /**
     * Clears the table then gets the programs again from the parser.
     *
     * synchronized might not be necessary but maybe if the timer and button is pressed at the same time
     * something might not go as planned.
     */
    private synchronized void refreshTable(){
        channel.clearTable();
        ParseChannel parseChannel = new ParseChannel(channel);
        parseChannel.execute();
        System.out.println("refreshed");
    }

}
