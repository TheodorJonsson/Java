/**
 * The JFrame for the individual channels and their programs
 * if closed can be opened from the main frames menubar.
 *
 *
 * Written and compiled in Java 17
 *
 * @Author Theodor Jonsson (ens18trn)
 * @date 2023-01-09
 */
package radioGUI;

import radioController.RefreshController;
import radioXML.Channel;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.net.MalformedURLException;
import java.net.URL;


public class ScheduleMenu extends JFrame{
    private JPanel centerPanel;
    private JSplitPane north;
    private Channel channel;



    private JButton refreshButton;

    public ScheduleMenu(Channel channel){
        setTitle(channel.getName());
        this.channel = channel;
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        //the centerPanel will contain the table for the channel.
        centerPanel = new JPanel(new GridLayout());
        createNorthPanel(channel);

        centerPanel.add(new JScrollPane(channel.getProgram()));

        add(centerPanel, BorderLayout.CENTER);
        add(north, BorderLayout.NORTH);
        //Handles the refresh button and the timer for refresh
        RefreshController controller = new RefreshController(this, channel);
        setVisible(true);
        pack();
    }

    /**
     * Creates the north panel which contains the name of the channel,
     * the image of the channel, the tagline of the channel and a refresh button.
     * @param channel, it's channel
     */
    private void createNorthPanel(Channel channel) {
        JPanel northEast = new JPanel();
        ImageIcon image = getImageIcon();
        JLabel label = new JLabel( image, JLabel.LEFT);
        label.setPreferredSize(new Dimension(60,60));
        northEast.add(label);

        JTextArea tagLine = createTextAreaForTagLine(channel);
        northEast.add(tagLine);
        northEast.setBorder(new LineBorder(Color.BLACK));

        JPanel northWest = new JPanel();
        northWest.setLayout(new GridLayout(2,1));
        refreshButton = new JButton("refresh");


        JLabel titleLabel = new JLabel(channel.getName(), JLabel.CENTER);
        northWest.add(titleLabel);
        northWest.add(refreshButton);

        north = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, northWest, northEast);

    }


    /**
     * Gets the tagline for the channel and creates a textarea for that tagline
     * @param channel
     * @return tagLine, which is a textArea with the tagLine
     */
    private JTextArea createTextAreaForTagLine(Channel channel) {
        JTextArea tagLine = new JTextArea();
        tagLine.setLineWrap(true);
        tagLine.setText(channel.getTagline());
        tagLine.setLayout(new FlowLayout());
        tagLine.setPreferredSize(new Dimension(720,60));
        tagLine.setEditable(false);
        return tagLine;
    }

    /**
     * Gets the image for the channel, if the url doesnt work adds a error image instead.
     * @return imageIcon, a Icon of that image.
     */
    private ImageIcon getImageIcon()  {
        URL url = null;
        ImageIcon imageIcon = null;
        try {
            url = new URL(channel.getImage());
            imageIcon = new ImageIcon(url);
        } catch (MalformedURLException e) {
            imageIcon = new ImageIcon("/resources/errorSign.png");
        }

        Image image = imageIcon.getImage();
        Image newImg = image.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newImg);
        return imageIcon;
    }

    public JButton getRefreshButton() {
        return refreshButton;
    }
}
