/**
 * Holds the data for the individual channel. Creates the JTable
 * and gets the data gathered from parseChannel and adding it to the JTable
 *
 * Written and compiled in Java 17
 *
 * @Author Theodor Jonsson (ens18trn)
 * @date 2023-01-09
 */

package radioXML;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;

public class Channel {
    private String name;
    private String id;
    private String image;
    private String tagline;
    private JTable program;
    private DefaultTableModel tableModel;
    private ParseChannel parseEpisodes;

    public Channel() {
    }

    public JTable getProgram(){
        return program;
    }


    /**
     * Creates the table model and adds the title columns for the table
     * then creates the JTable with the table model
     */
    public void createTable(){
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Program name");
        tableModel.addColumn("Starttime");
        tableModel.addColumn("Endtime");
        program = new JTable(tableModel);
    }

    /**
     * Adds the data to the table model
     * @param datalist
     */
    public void addToTable(ArrayList<String[]> datalist){
        for(int i = 0; i < datalist.size(); i++){
            tableModel.addRow(datalist.get(i));
        }
    }

    public void clearTable(){
        tableModel.setRowCount(0);
    }

    /**
     * @return the name of the channel
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @return the id of the channel
     */
    public String getId() {
        return id;
    }

    /**
     *
     * @return the image string of the channel
     */
    public String getImage() {
        return image;
    }

    /**
     *
     * @return the tagline of the channel
     */
    public String getTagline() {
        return tagline;
    }

    /**
     * sets the name of the channel
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * sets the id of the channel
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * sets the string to the url of the image for the channel
     * @param image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * sets the tagline to the channel
     * @param tagline
     */
    public void setTagline(String tagline) {
        this.tagline = tagline;
    }

    @Override
    public String toString(){
        return name + " " + id + " " + tagline + " " + image;
    }

}
