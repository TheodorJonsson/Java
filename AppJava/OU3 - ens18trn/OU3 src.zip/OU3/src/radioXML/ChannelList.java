/**
 * Holds the channels for the JList with all channels and starts parseXMLAllChannels to
 * gather all the channels and put them in the JList
 *
 * Written and compiled in Java 17
 *
 * @Author Theodor Jonsson (ens18trn)
 * @date 2023-01-09
 */
package radioXML;

import java.util.*;
import radioGUI.MainMenu;
import javax.swing.*;
import java.util.List;


public class ChannelList{

    private DefaultListModel listModel;
    private JList channels;
    private ArrayList<Channel> listOfChannels = new ArrayList<>();
    private List<JPanel> listOfPanels = new ArrayList<>();
    private MainMenu menu;
    private parseXMLAllChannels parse;
    private boolean parsed = false;


    /**
     * Creates the ChannelList and starts the SwingWorker.
     * @param menu
     */
    public ChannelList(MainMenu menu) {
        this.menu = menu;
        parse = new parseXMLAllChannels(this);
        parse.execute();
    }

    /**
     * Gets the data once again from the XML document
     */
    public void refreshChannelList(){
        listOfPanels.clear();
        parse = new parseXMLAllChannels(this);
        parse.execute();
    }

    public boolean isParsed() {
        return parsed;
    }


    /**
     * if parsed is true it will call the addToList method to add
     * all the panels to the JList
     * @param parsed
     */
    public void setParsed(boolean parsed) {
        this.parsed = parsed;
        if (isParsed() == true) {
            addToJList();
        }
    }

    /**
     * Adds the panels to the JList
     */
    public void addToJList() {
        menu.getListOfChannels().setListData(listOfPanels.toArray());
        menu.removeLoadingText();
        menu.getFrame().pack();
    }


   public JList getChannels() {
       return channels;
   }

    public ArrayList<Channel> getListOfChannels() {
        return listOfChannels;
    }

    public List<JPanel> getListOfPanels() {
        return listOfPanels;
    }

}

