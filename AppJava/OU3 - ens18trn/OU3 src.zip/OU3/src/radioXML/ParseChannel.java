/**
 * Handles the parsing of individual channels to get the
 * program for that channel. Stores all the data in a 2D array to be
 * sent to a table model.
 * Uses a SwingWorker to avoid locking the GUI
 *
 * Written and Compiled in Java 17
 *
 * @Author Theodor Jonsson
 * @Date 2023-01-09
 */

package radioXML;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutionException;



public class ParseChannel extends SwingWorker<ArrayList<String[]>, ArrayList<String[]>> {

    private Channel channel;

    public ParseChannel(Channel channel){
        this.channel = channel;
    }
    @Override
    protected ArrayList<String[]> doInBackground() {
        ArrayList<String[]> arrayOfStringArray = new ArrayList<>();
        try {
            NodeList rootList = getNodeList();

            for(int i = 0; i < rootList.getLength(); i++){
                Node allEpisodes = rootList.item(i);
                if(allEpisodes.getNodeType() == Node.ELEMENT_NODE){
                    NodeList scheduleList = allEpisodes.getChildNodes();
                    addEpisodesToStringArray(arrayOfStringArray, scheduleList);
                }
            }
        } catch (ParserConfigurationException e) {
            arrayOfStringArray.clear();
        } catch (SAXException e) {
            arrayOfStringArray.clear();
        } catch (IOException e) {
            arrayOfStringArray.clear();
        }

        return arrayOfStringArray;
    }

    /**
     * Goes through the nodelist of the XML document to find the title, starttime and endtime
     * and adds these strings to a string array when all three values have been found and added
     * add the string array to a 2D string
     * @param arrayOfStringArray, the 2D String array
     * @param scheduleList, This is the child nodelist of a node
     */
    private void addEpisodesToStringArray(ArrayList<String[]> arrayOfStringArray, NodeList scheduleList) {
        for(int j = 0; j < scheduleList.getLength(); j++){
            Node scheduledEpisode = scheduleList.item(j);
            if(scheduledEpisode.getNodeType() == Node.ELEMENT_NODE){
                String[] stringArray = new String[3];
                NodeList scheduledEpisodeList = scheduledEpisode.getChildNodes();
                Boolean hasBeenPublished = false;
                int isDone = 0;
                for(int k = 0; k < scheduledEpisodeList.getLength(); k++){
                    Node episode = scheduledEpisodeList.item(k);
                    if(episode.getNodeType() == Node.ELEMENT_NODE){
                        if(episode.getNodeName().equals("title")){
                            stringArray[0] = episode.getTextContent();
                            isDone++;
                        }
                        if(episode.getNodeName().equals("starttimeutc")){
                            stringArray[1] = getTimeInLocal(episode.getTextContent());
                            if(stringArray[1] != null){
                                isDone++;
                            }
                        }
                        if(episode.getNodeName().equals("endtimeutc")){
                            stringArray[2] = getTimeInLocal(episode.getTextContent());
                            if(stringArray[2] != null){
                                isDone++;
                            }
                        }
                        if(isDone == 3 && hasBeenPublished == false){
                            hasBeenPublished = true;
                            arrayOfStringArray.add(stringArray);
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets a nodelist of the XML document
     * @return rootlist
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private NodeList getNodeList() throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        String url = "http://api.sr.se/api/v2/scheduledepisodes?channelid="+channel.getId()+"&pagination=false";
        Document doc = builder.parse(new URL(url).openStream());
        Element rootElement = doc.getDocumentElement();
        NodeList rootList = doc.getElementsByTagName("schedule");
        return rootList;
    }

    /**
     * Sends the data gathered to the channel to be added to its table model.
     */
    @Override
    protected void done() {
        try {
            if(!get().isEmpty()){
                channel.addToTable(get());
            }
            else{
                JOptionPane.showMessageDialog(null, "Could not find any episodes", "Error", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (InterruptedException e) {
            JOptionPane.showMessageDialog(null, e.getCause().getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        } catch (ExecutionException e) {
            JOptionPane.showMessageDialog(null, e.getCause().getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    /**
     * Checks if the time is within bounds of 6h before and 12 hours after the current time.
     * If it is it will return a string of the episode time in local time zone.
     * If not it will return null showing that it wasn't in bounds.
     *
     * This method handles checking both start time and end time
     * @param episodeTime
     * @return timeOfEpisode, in format HH:MM:SS
     */
    public String getTimeInLocal(String episodeTime){
        //Gets the current time in UTC so it becomes easier to compare and parses input
        //String to a date format
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        OffsetDateTime epTime = OffsetDateTime.parse(episodeTime);

        //Gets the time between current time and episode time
        Duration pastDuration = Duration.between(epTime, now);
        Duration futureDuration = Duration.between(now, epTime);

        //Checks if the time is within bounds
        if(pastDuration.toHours() >= 6 || futureDuration.toHours() >= 12){
            return null;
        }

        //Translates the time to local time zone of the current system
        ZonedDateTime zoned = epTime.atZoneSameInstant(ZoneId.systemDefault());
        LocalDateTime localZoneEpTime = zoned.toLocalDateTime();
        String timeOfEpisode = localZoneEpTime.toLocalTime().toString();
        return timeOfEpisode;

    }
}
