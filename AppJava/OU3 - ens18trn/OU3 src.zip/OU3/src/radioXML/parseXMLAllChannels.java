/**
 * @Class parseXMLAllChannels
 * Handles the parsing of the XML document that has all the channels.
 * The class also handles the creation of the JPanels with the image and name
 * of the channel. Sends this data to the ChannelList object to be displayed
 * Uses a SwingWorker to avoid locking the GUI
 *
 *
 * Written and Compiled in Java 17
 *
 * @Author Theodor Jonsson
 * @Date 2023-01-09
 */

package radioXML;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.awt.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;




public class parseXMLAllChannels extends SwingWorker<List<Channel>, List<Channel>> {
    private ChannelList list;
    //private List<Channel> listChannels = new ArrayList<>();
    private List<JPanel> listOfPanels = new ArrayList<>();
    public parseXMLAllChannels(ChannelList list){
        this.list = list;
    }
    @Override
    protected List<Channel> doInBackground(){
        List<Channel> listChannels = new ArrayList<>();
        try {
            NodeList channelList = parsingXMLDOM();
            addChannels(listChannels, channelList);

        }catch (MalformedURLException e) {
            listChannels.clear();
        } catch (IOException e) {
            listChannels.clear();
        } catch (SAXException e) {
            listChannels.clear();
        } catch (ParserConfigurationException e) {
            listChannels.clear();
        }

        return listChannels;
    }

    /**
     * Parses the XML document and returns a nodelist of all nodes with the tag "channel"
     * @return channelList, a NodeList.
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private NodeList parsingXMLDOM() throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(new URL("http://api.sr.se/api/v2/channels?pagination=false").openStream());
        Element rootElement = doc.getDocumentElement();
        NodeList channelList = doc.getElementsByTagName("channel");
        return channelList;
    }

    /**
     * retrieves the attributes and nodes of each channel and creates a channel object
     * to place these in to later place in the list.
     * @param channels
     * @param channelList
     * @return
     */
    private void addChannels(List<Channel> channels, NodeList channelList) {

        for(int i = 0; i < channelList.getLength(); i++){
            Node channelNode = channelList.item(i);
            if(channelNode.getNodeType() == Node.ELEMENT_NODE) {
                Channel channel = new Channel();
                Element channelEle = (Element) channelNode;
                channel.setName(channelEle.getAttribute("name"));
                channel.setId(channelEle.getAttribute("id"));

                NodeList childChannelNodeList = channelNode.getChildNodes();
                getChildAttributes(channel, childChannelNodeList);
                channels.add(channel);
            }
        }

    }

    /**
     * Gets the contents of the child nodes of the channel
     * @param newChannel
     * @param childChannelNodeList
     */
    private void getChildAttributes(Channel newChannel, NodeList childChannelNodeList) {
        for(int j = 0; j < childChannelNodeList.getLength(); j++){
            Node childNode = childChannelNodeList.item(j);
            if(childNode.getNodeType() == Node.ELEMENT_NODE){
                if(childNode.getNodeName().equals("image")){
                    newChannel.setImage(childNode.getTextContent());
                }
                if(childNode.getNodeName().equals("tagline")){
                    newChannel.setTagline(childNode.getTextContent());
                }
            }
        }
    }

    /**
     * Creates the panels that a with the name of and image from the channel objects
     * @param listChannels
     * @param listOfPanels
     */
    private void createPanels(List<Channel> listChannels){
        for (int i = 0; i < listChannels.size(); i++) {
            if (listChannels.get(i).getImage() != null) {
                ImageIcon imageIcon = getImageIcon(i, listChannels);
                JLabel label = new JLabel(listChannels.get(i).getName(), imageIcon, JLabel.LEFT);
                JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                panel.add(label);
                listOfPanels.add(panel);
            }
        }
    }
    /**
     * Gets the image icon from a url in the channel
     * If url doesnt work adds a error image instead
     * @param i, current index
     * @param listChannels, the list of channels
     * @return
     * @throws MalformedURLException
     */
    private ImageIcon getImageIcon(int i, List<Channel> listChannels)  {
        URL url = null;
        ImageIcon imageIcon = null;
        try {
            url = new URL(listChannels.get(i).getImage());
            imageIcon = new ImageIcon(url);
        } catch (MalformedURLException e) {
            imageIcon = new ImageIcon("/resources/errorSign.png");
        }
        Image image = imageIcon.getImage();
        Image newImg = image.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        imageIcon = new ImageIcon(newImg);
        return imageIcon;
    }

    /**
     * Runs after doInBackground is completed and sends all the panels and channels
     * to the list of channels.
     */
    @Override
    protected void done(){
        try {
            List<Channel> channels = get();
            createPanels(channels);
            if(!channels.isEmpty()){
                for(int i = 0; i < listOfPanels.size(); i++){
                    list.getListOfChannels().add(channels.get(i));
                    list.getListOfPanels().add(listOfPanels.get(i));
                }
                //Checks that all is done and all information can be added to the JList.
                list.setParsed(true);
            }
            else{
                JOptionPane.showMessageDialog(null, "Could not find any Channels.", "Error", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (InterruptedException e) {
            JOptionPane.showMessageDialog(null, e.getCause().getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        } catch (ExecutionException e) {
            JOptionPane.showMessageDialog(null, e.getCause().getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }

}
